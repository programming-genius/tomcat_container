--
-- PostgreSQL database dump
--

-- Dumped from database version 11.11
-- Dumped by pg_dump version 11.11

-- Started on 2021-12-15 11:33:42

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;


CREATE TABLE public.pagina (
    id integer NOT NULL,
    titolo character varying,
    contenuto character varying,
    modifica date
);


ALTER TABLE public.pagina OWNER TO postgres;

CREATE SEQUENCE public.pagina_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pagina_id_seq OWNER TO postgres;
ALTER SEQUENCE public.pagina_id_seq OWNED BY public.pagina.id;

CREATE TABLE public.autore (
    id integer NOT NULL,
    nome character varying
);

CREATE SEQUENCE public.autore_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.autore_id_seq OWNER TO postgres;
ALTER SEQUENCE public.autore_id_seq OWNED BY public.pagina.id;

CREATE TABLE public.pagine_autore (
    id_pagina integer NOT NULL,
    id_autore integer NOT NULL
);

ALTER TABLE ONLY public.pagina ALTER COLUMN id SET DEFAULT nextval('public.pagina_id_seq'::regclass);
ALTER TABLE ONLY public.autore ALTER COLUMN id SET DEFAULT nextval('public.autore_id_seq'::regclass);
ALTER TABLE ONLY public.pagina ADD CONSTRAINT pagina_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.autore ADD CONSTRAINT autore_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.pagine_autore ADD CONSTRAINT pagine_autore_pkey PRIMARY KEY (id_pagina, id_autore);